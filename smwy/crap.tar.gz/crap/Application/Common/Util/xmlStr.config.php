<?php
/**
*	΢��xml���ݱ�����Сд��Ӧ�����ļ�
*	@author Dragondean
*	@Date 2015-05-14
*/

return array(
	'tousername' => 'ToUserName',
	'fromusername' => 'FromUserName',
	'createtime' => 'CreateTime',
	'msgtype' => 'MsgType',
	'content' => 'Content',
	'image' => 'Image',
	'mediaid' => 'MediaId',
	'voice' => 'Voice',
	'video' => 'Video',
	'title' => 'Title',
	'description' => 'Description',
	'music' => 'Music',
	'musicurl' => 'MusicUrl',
	'hqmusicutl' => 'HQMusicUrl',
	'thumbmediaid' => 'ThmubMediaId',
	'articlecount' => 'ArticleCount',
	'articles' => 'Articles',
	'picurl' => 'PicUrl',
	'url' => 'Url'
);