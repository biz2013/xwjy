<?php
return array(
	//'配置项'=>'配置值'
	'LOAD_EXT_CONFIG' 	=> 'admin',
	'LAYOUT_ON'=>true,
	'LAYOUT_NAME'=>'layout',
);