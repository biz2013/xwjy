<?php
return array(
	//'配置项'=>'配置值'
	'ADMIN_NAME' => 'admin',
	'ADMIN_PASS' => '0ba20fa90177c0540747df3f33ab8b0f'
);